package com.example.josesamo.myapplication.backend;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by josesamo on 6/28/17.
 */

public class Test extends HttpServlet {



    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {


        resp.getWriter().println("WORKING IN MAIN THREAD");



    }

}
